document.addEventListener('DOMContentLoaded', () => {
  const pokedexForm = document.getElementById('pokedexForm');
  const pokedexEntries = document.getElementById('pokedexEntries');

  pokedexForm.addEventListener('submit', async (event) => {
    event.preventDefault();

    const formData = new FormData(pokedexForm);
    const newEntry = {};
    formData.forEach((value, key) => {
      newEntry[key] = value;
    });

    const response = await fetch('/pokedex', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(newEntry)
    });

    if (response.ok) {
      alert('Pokedex entry added successfully!');
      loadPokedexEntries();
    } else {
      alert('Failed to add entry to Pokedex');
    }
  });

  async function loadPokedexEntries() {
    try {
      const response = await fetch('/pokedex');
      if (!response.ok) {
        throw new Error('Failed to fetch Pokedex entries');
      }

      const entries = await response.json();
      displayPokedexEntries(entries);
    } catch (error) {
      console.error('Error fetching Pokedex entries:', error.message);
    }
  }

  function displayPokedexEntries(entries) {
    pokedexEntries.innerHTML = '';

    if (!Array.isArray(entries)) {
      console.error('Unexpected data format received:', entries);
      return;
    }

    entries.forEach(entry => {
      const entryDiv = document.createElement('div');
      entryDiv.innerHTML = `
        <p>Name: ${entry.name}</p>
        <p>Number: ${entry.number}</p>
        <p>Type: ${entry.type}</p>
        <p>Description: ${entry.description}</p>
        <hr>
      `;
      pokedexEntries.appendChild(entryDiv);
    });
  }

  loadPokedexEntries();
});
